Hp2RepeatThreesomeMod V1.1, 4/11/2021

--Contributors--
onesuchkeeper - design, programming, research, testing

To help with development, please consider supporting me on patreon - https://www.patreon.com/onesuchkeeper

--Description--
This mod allows for repeat bonus rounds when characters are at the 'Lovers" stage. If you go on a date at the right location and at the right time of day the bonus round will play again. 

This mod includes two new unlock codes! 
"DOHOONKABHANKOLOOS", which toggles nudity durring the bonus rounds.
For the second I took a page out of HunieDev's book and decided to make is seceret. Here's a hint: FNOCNFOBHeNBe

--To Install--
To install, first install the Hp2BaseMod and then place in the 'mods' folder.