Hp2BaseModTweaks V1.1, 3/5/2021

--Contributers--
onesuchkeeper - design, programming, research, testing

To help with development, please consider supporting me on patreon - https://www.patreon.com/onesuchkeeper

--Description--
This mod requires the Hp2BaseMod to be installed. Adds simple tweaks for some flavor in the base mod. At the moment it just Changes the logo. This is unessential to the base mod and can be removed if desired. This mod has no lasting effects on the installation.

--To Install--
To install, first install the Hp2BaseMod and then place in the 'mods' folder. I don't know why you would ever install this manually though, it's included in the base mod.