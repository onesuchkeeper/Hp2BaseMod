Hp2LadyJizzMod V1.1, 4/11/2021

--Contributors--
onesuchkeeper - design, programming, research, testing

To help with development, please consider supporting me on patreon - https://www.patreon.com/onesuchkeeper

--Description--
This mod removes the disabling of Jizz-photos if you selected female as you gender.

THis mod includes 1 code unlock:
"JIZZ FOR ALL" will toggle jizz photos being available while your players character is female.

--To Install--
To install, first install the Hp2BaseMod and then place in the 'mods' folder.